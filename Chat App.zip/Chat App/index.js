const app = require('express')();
const server = require('http').Server(app);
const io = require('socket.io')(server);

const port = 3000;

server.listen(port, () => {
    console.log('server is listening on port:' + port);
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

app.get('/student', (req, res) => {
    res.sendFile(__dirname + '/public/student.html');
});

app.get('/teacher', (req, res) => {
    res.sendFile(__dirname + '/public/teacher.html');
});

app.get('/online', (req, res) => {
    res.sendFile(__dirname + '/public/online.html');
});

const tech = io.of('/tech');

tech.on('connection', (socket) => {


    socket.on('join', (data) => {
        console.log(data);
        socket.join(data.room);
        tech.in(data.room).emit('message', {msg: `a new user joined ${data.room}  room!`, uid: 0});
        console.log(`A new user has connected to ${data.room} room!`);
    });


    socket.on('message', (data) => {
        tech.in(data.room).emit('message', data );
        console.log('A message has been sent: ( ' + data.msg + ` ) to ${data.room}`);
    });


    socket.on('disconect', function () {
        socket.rooms.forEach(function (room) {
            io.in(room).emit('user: disconnect', { id: socket.id });
        });
        console.log('user out')
    });

});

