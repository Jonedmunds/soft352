const app = require('express')();
const server = require('http').Server(app);
const io = require('socket.io')(server);

const port = 3000;

server.listen(port, ()=>{
    console.log('server is listening on port:' + port);
});

app.get('/',(req,res)=>{
    res.sendFile(__dirname + '/public/index.html');
});

app.get('/student', (req, res)=>{
    res.sendFile(__dirname + '/public/student.html');
});

app.get('/teacher', (req, res)=>{
    res.sendFile(__dirname + '/public/teacher.html');
});

app.get('/studentTeacher', (req, res)=>{
    res.sendFile(__dirname + '/public/studentTeacher.html');
});

app.get('/home', (req, res)=>{
    res.sendFile(__dirname + '/public/home.html');
});

const tech = io.of('/tech');

tech.on('connection', (socket) =>{

    
    socket.on('join', (data) =>{
        socket.join(data.room);
        tech.in(data.room).emit('message', `new user joined ${data.room}  room!`);
        console.log(`A new user has connected to ${data.room} room!`); 
    });

    
    socket.on('message', (data) =>{
        tech.in(data.room).emit('message', data.msg);
        console.log('A message has been sent: ( '+ data.msg + ` ) to ${data.room}`);
    });

    
    io.on('disconect', () =>{
        console.log('user disconected');
        tech.emit('message' , 'User Left The room');
        
    });
 
});

