var WebSocketServer = require("websocket").server;
var http = require("http");

var server = http.createServer(function (request, response) {
	console.log(new Date() + "Revived request");
});

server.listen(9000, function() {
	console.log(new Date() + " Handshake from server");
});

var socket = new WebSocketServer({
	httpServer: server
});

socket.on ("request", function(request){
	var connection = request.accept(null, request.origin);
	connection.on("close", function(reasonCode, description){
		console.log("Connection closed");
	});
	connection.on("message", function (message){
		console.log(message.utf8Data);
		connection.sendUTF("Hello world from server");
	});
	rl.question("Enter message for client ", function(answer) {
		connection.sendUTF(answer + " " + new Date());

	console.log("sent message", answer, " to client");
	});
});

var readline = require("readline");

var rl =  readline.createInterface({
	input: process.stdin,
	output:process.stdout
});
